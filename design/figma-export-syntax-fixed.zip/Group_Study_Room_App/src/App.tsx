import { useEffect, useState, type ReactNode } from "react"

type IconName = "board" | "screen" | "code" | "users" | "message" | "help" | "rank" | "mic" | "video" | "hand" | "share" | "more" | "grid" | "leave" | "invite" | "moon" | "sun" | "chevron" | "play" | "pause" | "pen" | "eraser" | "shape" | "arrow" | "type" | "image" | "laser" | "undo" | "redo" | "zoom" | "download" | "check" | "copy" | "signal" | "home" | "calendar" | "stats" | "settings" | "plus" | "clock" | "target" | "flame" | "link" | "bell" | "key" | "book" | "whatsapp" | "close"

const paths: Record<IconName, ReactNode> = {
  board: (
    <>
      <path d="M4 3h16v14H4z" />
      <path d="M8 21h8M12 17v4" />
    </>
  ),
  screen: (
    <>
      <rect x="3" y="4" width="18" height="12" rx="1" />
      <path d="m8 21 4-5 4 5" />
    </>
  ),
  code: (
    <>
      <path d="m8 9-3 3 3 3M16 9l3 3-3 3M14 5l-4 14" />
    </>
  ),
  users: (
    <>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </>
  ),
  message: (
    <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" />
  ),
  help: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M9.8 9a2.3 2.3 0 1 1 3.8 1.75c-.9.7-1.6 1.1-1.6 2.25M12 17h.01" />
    </>
  ),
  rank: (
    <>
      <path d="M4 20V10h4v10M10 20V4h4v16M16 20v-7h4v7" />
    </>
  ),
  mic: (
    <>
      <rect x="9" y="2" width="6" height="12" rx="3" />
      <path d="M5 10a7 7 0 0 0 14 0M12 17v4M8 21h8" />
    </>
  ),
  video: (
    <>
      <rect x="3" y="6" width="13" height="12" rx="2" />
      <path d="m16 10 5-3v10l-5-3" />
    </>
  ),
  hand: (
    <path d="M7 11V6a1.5 1.5 0 0 1 3 0v4-6a1.5 1.5 0 0 1 3 0v6-5a1.5 1.5 0 0 1 3 0v6-3a1.5 1.5 0 0 1 3 0v6c0 5-3 8-8 8-3 0-5-2-6-4l-2-4a1.7 1.7 0 0 1 3-2l1 2" />
  ),
  share: (
    <>
      <circle cx="18" cy="5" r="3" />
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="19" r="3" />
      <path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4" />
    </>
  ),
  more: (
    <>
      <circle cx="5" cy="12" r="1" />
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
    </>
  ),
  grid: (
    <>
      <rect x="3" y="3" width="7" height="7" />
      <rect x="14" y="3" width="7" height="7" />
      <rect x="3" y="14" width="7" height="7" />
      <rect x="14" y="14" width="7" height="7" />
    </>
  ),
  leave: (
    <>
      <path d="M10 17l5-5-5-5M15 12H3" />
      <path d="M14 3h6a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-6" />
    </>
  ),
  invite: (
    <>
      <path d="M15 19c0-3-2-5-5-5H6c-3 0-5 2-5 5" />
      <circle cx="8" cy="7" r="4" />
      <path d="M19 8v6M16 11h6" />
    </>
  ),
  moon: <path d="M21 13a9 9 0 1 1-10-10 7 7 0 0 0 10 10" />,
  sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
    </>
  ),
  chevron: <path d="m9 18 6-6-6-6" />,
  play: <path d="m8 5 11 7-11 7z" />,
  pause: (
    <>
      <path d="M8 5v14M16 5v14" />
    </>
  ),
  pen: (
    <>
      <path d="m4 20 4-1 11-11-3-3L5 16z" />
      <path d="m14 7 3 3" />
    </>
  ),
  eraser: (
    <>
      <path d="m7 20-4-4L14 5l6 6-9 9z" />
      <path d="m11 20 9-9" />
    </>
  ),
  shape: (
    <>
      <rect x="3" y="3" width="8" height="8" />
      <circle cx="16.5" cy="16.5" r="4.5" />
    </>
  ),
  arrow: (
    <>
      <path d="M4 20 20 4M12 4h8v8" />
    </>
  ),
  type: (
    <>
      <path d="M4 5h16M12 5v14M8 19h8" />
    </>
  ),
  image: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <circle cx="8.5" cy="9" r="1.5" />
      <path d="m3 16 5-5 4 4 3-3 6 6" />
    </>
  ),
  laser: (
    <>
      <circle cx="12" cy="12" r="2" />
      <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
    </>
  ),
  undo: (
    <>
      <path d="m9 7-5 5 5 5" />
      <path d="M20 17a8 8 0 0 0-13-6" />
    </>
  ),
  redo: (
    <>
      <path d="m15 7 5 5-5 5" />
      <path d="M4 17a8 8 0 0 1 13-6" />
    </>
  ),
  zoom: (
    <>
      <circle cx="10" cy="10" r="6" />
      <path d="m15 15 6 6M10 7v6M7 10h6" />
    </>
  ),
  download: (
    <>
      <path d="M12 3v12M7 10l5 5 5-5" />
      <path d="M4 21h16" />
    </>
  ),
  check: <path d="m5 12 4 4L19 6" />,
  copy: (
    <>
      <rect x="8" y="8" width="12" height="12" rx="2" />
      <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" />
    </>
  ),
  signal: (
    <>
      <path d="M5 16a10 10 0 0 1 14 0M8 19a6 6 0 0 1 8 0M12 22h.01" />
    </>
  ),
  home: (
    <>
      <path d="m3 11 9-8 9 8" />
      <path d="M5 10v10h14V10M9 20v-6h6v6" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </>
  ),
  stats: (
    <>
      <path d="M4 19V9M10 19V5M16 19v-7M22 19V2" />
      <path d="M2 19h21" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.8 1.8 0 0 0 .36 2l.06.06-2.12 2.12-.06-.06a1.8 1.8 0 0 0-2-.36 1.8 1.8 0 0 0-1.1 1.65V21h-3v-.09a1.8 1.8 0 0 0-1.1-1.65 1.8 1.8 0 0 0-2 .36l-.06.06-2.12-2.12.06-.06a1.8 1.8 0 0 0 .36-2 1.8 1.8 0 0 0-1.65-1.1H4v-3h.09a1.8 1.8 0 0 0 1.65-1.1 1.8 1.8 0 0 0-.36-2l-.06-.06 2.12-2.12.06.06a1.8 1.8 0 0 0 2 .36 1.8 1.8 0 0 0 1.1-1.65V3h3v.09a1.8 1.8 0 0 0 1.1 1.65 1.8 1.8 0 0 0 2-.36l.06-.06 2.12 2.12-.06.06a1.8 1.8 0 0 0-.36 2 1.8 1.8 0 0 0 1.65 1.1H21v3h-.09A1.8 1.8 0 0 0 19.4 15z" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="12" cy="12" r="1" />
    </>
  ),
  flame: (
    <path d="M12 22c4 0 7-3 7-7 0-3-1.5-5.5-4-8 .2 3-1 4-2 5 0-4-2-7-5-10 .3 5-3 7-3 12 0 4.4 3 8 7 8z" />
  ),
  link: (
    <>
      <path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1 1" />
      <path d="M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1-1" />
    </>
  ),
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
      <path d="M10 21h4" />
    </>
  ),
  key: (
    <>
      <circle cx="8" cy="15" r="4" />
      <path d="m11 12 9-9M16 4l4 4" />
    </>
  ),
  book: (
    <>
      <path d="M4 19a2 2 0 0 1 2-2h14V4H6a2 2 0 0 0-2 2z" />
      <path d="M4 6v13a2 2 0 0 0 2 2h14" />
    </>
  ),
  whatsapp: (
    <>
      <path d="M20 11.5a8 8 0 0 1-11.8 7L4 20l1.4-4A8 8 0 1 1 20 11.5z" />
      <path d="M9 8c.5 3 2 4.5 5 5" />
    </>
  ),
  close: <path d="m6 6 12 12M18 6 6 18" />,
}

function Icon({ name, size = 16 }: { name: IconName; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

type ViewName = "join" | "home" | "room" | "schedule" | "stats" | "quiz" | "features" | "settings" | "recap"

function Field({
  label,
  value,
  type = "text",
  disabled = false,
}: {
  label: string
  value: string
  type?: string
  disabled?: boolean
}) {
  return (
    <label className={`field ${disabled ? "disabled" : ""}`}>
      <span>{label}</span>
      <input type={type} defaultValue={value} disabled={disabled} />
    </label>
  )
}

function Toggle({
  checked = false,
  disabled = false,
}: {
  checked?: boolean
  disabled?: boolean
}) {
  return (
    <span
      className={`toggle ${checked ? "checked" : ""} ${
        disabled ? "disabled" : ""
      }`}
    >
      <i />
    </span>
  )
}

function JoinView({
  theme,
  setTheme,
  onJoin,
}: {
  theme: "dark" | "light"
  setTheme: (theme: "dark" | "light") => void
  onJoin: () => void
}) {
  const [mic, setMic] = useState(true)
  const [camera, setCamera] = useState(false)
  return (
    <div className="join-page">
      <div className="join-top">
        <div className="wordmark">
          <span className="brand-mark">N</span>
          <strong>Notionroom</strong>
        </div>
        <Button
          icon={theme === "dark" ? "sun" : "moon"}
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        />
      </div>
      <div className="join-panel">
        <div className="join-eyebrow">
          <span className="live-dot" /> STUDY SESSION IN PROGRESS
        </div>
        <div className="title-lg">LRU Cache · Interview Prep</div>
        <p className="subtext">Hosted by Aarav Kumar · Topic: DSA</p>
        <div className="inside-row">
          <div className="avatar-stack">
            {participants.slice(0, 4).map((p) => (
              <span className={`avatar ${p.className}`} key={p.name}>
                {p.initials}
              </span>
            ))}
          </div>
          <strong>7 people inside</strong>
          <span>Session started 12 min ago</span>
        </div>
        <div className="self-preview">
          <div className="preview-person p-blue">YS</div>
          <span>Camera is off</span>
          <div className="preview-controls">
            <Button icon="mic" active={mic} onClick={() => setMic(!mic)} />
            <Button
              icon="video"
              active={camera}
              onClick={() => setCamera(!camera)}
            />
          </div>
        </div>
        <Field label="YOUR NAME" value="You" />
        <div className="join-options">
          <span>Join as</span>
          <div>
            <Button active>Student</Button>
            <Button>Listener</Button>
            <Button>Mentor</Button>
          </div>
        </div>
        <Button variant="primary" className="join-main" onClick={onJoin}>
          Join study room <Icon name="chevron" />
        </Button>
        <Button className="account-button">Continue with account</Button>
        <div className="join-foot">
          <Icon name="signal" />
          <span>Connection looks good · Audio and board use less data</span>
        </div>
      </div>
    </div>
  )
}

function AppShell({
  view,
  onNavigate,
  theme,
  setTheme,
  children,
}: {
  view: ViewName
  onNavigate: (view: ViewName) => void
  theme: "dark" | "light"
  setTheme: (theme: "dark" | "light") => void
  children: ReactNode
}) {
  const nav: { id: ViewName; icon: IconName; label: string }[] = [
    { id: "home", icon: "home", label: "Rooms" },
    { id: "schedule", icon: "calendar", label: "Schedule" },
    { id: "stats", icon: "stats", label: "Stats" },
    { id: "quiz", icon: "help", label: "Quiz" },
    { id: "features", icon: "book", label: "Core" },
  ]
  return (
    <div className="product-shell">
      <aside className="left-rail">
        <Button className="rail-brand" onClick={() => onNavigate("home")}>
          <span className="brand-mark">N</span>
        </Button>
        <nav>
          {nav.map((item) => (
            <Button
              key={item.id}
              icon={item.icon}
              active={view === item.id}
              onClick={() => onNavigate(item.id)}
              title={item.label}
            >
              <span>{item.label}</span>
            </Button>
          ))}
        </nav>
        <div className="rail-bottom">
          <Button
            icon={theme === "dark" ? "sun" : "moon"}
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            title="Change theme"
          />
          <Button
            icon="settings"
            active={view === "settings"}
            onClick={() => onNavigate("settings")}
            title="Settings"
          />
        </div>
      </aside>
      <div className="shell-body">{children}</div>
      <nav className="mobile-nav">
        {nav.slice(0, 4).map((item) => (
          <Button
            key={item.id}
            icon={item.icon}
            active={view === item.id}
            onClick={() => onNavigate(item.id)}
          >
            <span>{item.label}</span>
          </Button>
        ))}
      </nav>
    </div>
  )
}

function PageHeader({
  title,
  description,
  action,
}: {
  title: string
  description: string
  action?: ReactNode
}) {
  return (
    <header className="page-header">
      <div>
        <div className="title-md">{title}</div>
        <p>{description}</p>
      </div>
      {action}
    </header>
  )
}

function StatCell({
  icon,
  value,
  label,
  detail,
}: {
  icon: IconName
  value: string
  label: string
  detail: string
}) {
  return (
    <div className="stat-cell">
      <Icon name={icon} />
      <div>
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
      <small>{detail}</small>
    </div>
  )
}

function HomeView({ onNavigate }: { onNavigate: (view: ViewName) => void }) {
  return (
    <div className="page">
      <PageHeader
        title="Good evening, Aarav"
        description="Your next study session starts in 48 minutes."
        action={
          <div className="header-actions">
            <Button icon="link" onClick={() => onNavigate("join")}>
              Join from link
            </Button>
            <Button icon="bell" />
            <Button
              variant="primary"
              icon="plus"
              onClick={() => onNavigate("room")}
            >
              Start a room
            </Button>
          </div>
        }
      />
      <section className="start-strip">
        <div>
          <span className="section-kicker">QUICK START</span>
          <strong>What are you working on?</strong>
        </div>
        <Field label="TOPIC" value="DSA · Linked Lists" />
        <Field label="SESSION GOAL" value="Solve 3 LRU questions" />
        <div className="mode-options">
          <Button icon="users" active>
            Study together
          </Button>
          <Button icon="board">Teach</Button>
          <Button icon="target">Solo focus</Button>
        </div>
        <Button variant="primary" onClick={() => onNavigate("room")}>
          Start now
        </Button>
      </section>
      <section className="stats-strip">
        <StatCell
          icon="clock"
          value="14h 20m"
          label="Focused this week"
          detail="+2h 10m vs last week"
        />
        <StatCell
          icon="code"
          value="27"
          label="Problems solved"
          detail="8 medium · 3 hard"
        />
        <StatCell
          icon="help"
          value="18"
          label="Doubts answered"
          detail="82% answer rate"
        />
        <StatCell
          icon="flame"
          value="12 days"
          label="Current streak"
          detail="Personal best: 21"
        />
      </section>
      <div className="home-columns">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <strong>Upcoming sessions</strong>
              <span>Scheduled and recurring rooms</span>
            </div>
            <Button>View calendar</Button>
          </div>
          <div className="table">
            <div className="table-head">
              <span>SESSION</span>
              <span>TOPIC</span>
              <span>WHEN</span>
              <span>PEOPLE</span>
              <span />
            </div>
            {[
              [
                "System Design Mock",
                "System Design",
                "Today, 8:30 PM",
                "6 going",
              ],
              ["Dynamic Programming", "DSA", "Tomorrow, 7:00 PM", "12 going"],
              ["Database Indexes", "Databases", "Fri, 6:30 PM", "8 going"],
            ].map((row, i) => (
              <div className="table-row" key={row[0]}>
                <div>
                  <span className={`date-box ${i === 0 ? "today" : ""}`}>
                    {i === 0 ? "24" : "25"}
                    <small>MAR</small>
                  </span>
                  <strong>{row[0]}</strong>
                </div>
                <span>
                  <i className="topic-dot" />
                  {row[1]}
                </span>
                <span>{row[2]}</span>
                <span>{row[3]}</span>
                <Button onClick={() => onNavigate("room")}>
                  {i === 0 ? "Join" : "Details"}
                </Button>
              </div>
            ))}
          </div>
        </section>
        <section className="panel focus-panel">
          <div className="panel-heading">
            <div>
              <strong>This week</strong>
              <span>11–17 March</span>
            </div>
            <Button>Details</Button>
          </div>
          <div className="weekly-total">
            <strong>14:20</strong>
            <span>/ 18h goal</span>
          </div>
          <div className="chart">
            {[62, 80, 45, 92, 68, 38, 12].map((h, i) => (
              <div key={i}>
                <span style={{ height: `${h}%` }} />
                <small>{["M", "T", "W", "T", "F", "S", "S"][i]}</small>
              </div>
            ))}
          </div>
          <div className="goal-bar">
            <span style={{ width: "79%" }} />
            <b>79%</b>
          </div>
        </section>
      </div>
      <section className="panel recent-panel">
        <div className="panel-heading">
          <div>
            <strong>Recent rooms</strong>
            <span>Continue from your previous boards and notes</span>
          </div>
          <Button>Browse history</Button>
        </div>
        {[
          [
            "LRU Cache · Interview Prep",
            "DSA",
            "Today, 10:30 AM",
            "48 min",
            "3 problems · 4 doubts",
          ],
          [
            "Designing a URL Shortener",
            "System Design",
            "Yesterday",
            "1h 12m",
            "Board saved · 8 attendees",
          ],
          [
            "React Rendering Deep Dive",
            "React",
            "12 Mar",
            "54 min",
            "6 notes · 2 polls",
          ],
        ].map((r) => (
          <div className="recent-row" key={r[0]}>
            <div className="room-icon">
              <Icon name="book" />
            </div>
            <div>
              <strong>{r[0]}</strong>
              <span>
                {r[2]} · {r[4]}
              </span>
            </div>
            <span className="chip">{r[1]}</span>
            <code>{r[3]}</code>
            <Button icon="chevron" onClick={() => onNavigate("recap")} />
          </div>
        ))}
      </section>
    </div>
  )
}

function ScheduleView({
  onNavigate,
}: {
  onNavigate: (view: ViewName) => void
}) {
  return (
    <div className="page">
      <PageHeader
        title="Schedule"
        description="Plan recurring study rooms and focused teaching sessions."
        action={
          <Button variant="primary" icon="plus">
            Schedule session
          </Button>
        }
      />
      <div className="calendar-toolbar">
        <Button icon="chevron" />
        <strong>March 2025</strong>
        <Button icon="chevron" />
        <span />
        <Button active>Week</Button>
        <Button>Month</Button>
      </div>
      <div className="schedule-layout">
        <div className="week-grid">
          <div className="time-column">
            {["8 AM", "10 AM", "12 PM", "2 PM", "4 PM", "6 PM", "8 PM"].map(
              (t) => (
                <span key={t}>{t}</span>
              ),
            )}
          </div>
          {["MON 17", "TUE 18", "WED 19", "THU 20", "FRI 21"].map((d, i) => (
            <div className="day-column" key={d}>
              <strong>{d}</strong>
              {i === 0 && (
                <div className="event event-green">
                  <b>DSA Practice</b>
                  <span>8:30–9:30 AM · 8 people</span>
                </div>
              )}
              {i === 2 && (
                <div className="event event-amber">
                  <b>System Design Mock</b>
                  <span>2:00–3:30 PM · Mentor: Sana</span>
                </div>
              )}
              {i === 4 && (
                <div className="event event-blue">
                  <b>DB Indexes</b>
                  <span>6:30–7:30 PM · Recurring</span>
                </div>
              )}
            </div>
          ))}
        </div>
        <aside className="agenda">
          <div className="panel-heading">
            <div>
              <strong>Today</strong>
              <span>Monday, 17 March</span>
            </div>
          </div>
          <div className="agenda-time">8:30 AM</div>
          <div className="agenda-card">
            <span className="chip">DSA</span>
            <strong>DSA Practice</strong>
            <p>Goal: Solve 3 linked list problems</p>
            <div>
              <span>8 participants</span>
              <Button variant="primary" onClick={() => onNavigate("room")}>
                Join
              </Button>
            </div>
          </div>
          <div className="agenda-time">7:00 PM</div>
          <div className="agenda-card muted-card">
            <strong>Solo focus block</strong>
            <p>90 min · Revision notes</p>
          </div>
        </aside>
      </div>
    </div>
  )
}

function StatsView() {
  return (
    <div className="page">
      <PageHeader
        title="Study progress"
        description="Focus trends and learning outcomes across all your rooms."
        action={<Button icon="download">Export report</Button>}
      />
      <section className="stats-strip">
        <StatCell
          icon="clock"
          value="52h 40m"
          label="Total focus"
          detail="+18% this month"
        />
        <StatCell
          icon="flame"
          value="12 days"
          label="Study streak"
          detail="5 days to your record"
        />
        <StatCell
          icon="code"
          value="108"
          label="Problems solved"
          detail="71% first-attempt"
        />
        <StatCell
          icon="users"
          value="16"
          label="Sessions joined"
          detail="4 hosted by you"
        />
      </section>
      <div className="stats-grid">
        <section className="panel large-chart">
          <div className="panel-heading">
            <div>
              <strong>Focus time</strong>
              <span>Last 8 weeks</span>
            </div>
            <div>
              <Button active>Weekly</Button>
              <Button>Monthly</Button>
            </div>
          </div>
          <div className="bar-chart">
            {[7, 10, 8, 13, 11, 16, 14, 18].map((v, i) => (
              <div key={i}>
                <span style={{ height: `${v * 5}%` }}>
                  <b>{v}h</b>
                </span>
                <small>W{i + 1}</small>
              </div>
            ))}
          </div>
        </section>
        <section className="panel">
          <div className="panel-heading">
            <div>
              <strong>Topics studied</strong>
              <span>By focused time</span>
            </div>
          </div>
          {[
            ["DSA", "18h 20m", "42%"],
            ["System Design", "11h 10m", "26%"],
            ["Databases", "7h 30m", "17%"],
            ["React", "6h 40m", "15%"],
          ].map((x) => (
            <div className="topic-progress" key={x[0]}>
              <div>
                <strong>{x[0]}</strong>
                <code>{x[1]}</code>
              </div>
              <span>
                <i style={{ width: x[2] }} />
              </span>
            </div>
          ))}
        </section>
      </div>
      <section className="panel activity-table">
        <div className="panel-heading">
          <div>
            <strong>Learning activity</strong>
            <span>Recent milestones and room activity</span>
          </div>
        </div>
        {[
          "Aarav solved 2 problems in LRU Cache",
          "Meera marked your explanation as helpful",
          "You completed a 90-minute focus goal",
          "Sana answered your doubt about cache eviction",
          "Board saved from System Design Mock",
        ].map((a, i) => (
          <div key={a}>
            <span className="activity-icon">
              <Icon
                name={i === 1 || i === 3 ? "help" : i === 4 ? "board" : "check"}
              />
            </span>
            <strong>{a}</strong>
            <small>
              {
                [
                  "Today, 11:18 AM",
                  "Today, 10:54 AM",
                  "Yesterday, 8:32 PM",
                  "Yesterday, 7:16 PM",
                  "12 Mar, 9:04 PM",
                ][i]
              }
            </small>
          </div>
        ))}
      </section>
    </div>
  )
}

function QuizView() {
  const [started, setStarted] = useState(false)
  const [answer, setAnswer] = useState(1)
  const [revealed, setRevealed] = useState(false)
  return (
    <div className="page">
      <PageHeader
        title="Live quiz"
        description="LRU Cache · Question 3 of 5"
        action={
          <div className="quiz-timer">
            <span>TIME LEFT</span>
            <strong>00:24</strong>
          </div>
        }
      />
      <div className="quiz-layout">
        <section className="panel quiz-main">
          {!started ? (
            <div className="quiz-composer">
              <span className="section-kicker">HOST COMPOSER</span>
              <div className="title-md">Start a quick knowledge check</div>
              <Field
                label="QUESTION"
                value="Which operation makes an LRU Cache O(1)?"
              />
              <div className="option-inputs">
                {[
                  "Hash map + doubly linked list",
                  "Binary search tree",
                  "Priority queue",
                  "Array with linear scan",
                ].map((o, i) => (
                  <Field key={o} label={`OPTION ${i + 1}`} value={o} />
                ))}
              </div>
              <div className="composer-actions">
                <span>
                  Timer <Button active>30 sec</Button>
                </span>
                <span>
                  Correct answer <Button active>Option 1</Button>
                </span>
                <Button variant="primary" onClick={() => setStarted(true)}>
                  Start quiz
                </Button>
              </div>
            </div>
          ) : (
            <div className="question-live">
              <div className="live-question-head">
                <span className="chip">LIVE QUIZ</span>
                <span>16 of 19 answered</span>
              </div>
              <div className="title-lg">
                Which combination makes both get and put operations O(1) in an
                LRU Cache?
              </div>
              <div className="answer-list">
                {[
                  "Hash map + doubly linked list",
                  "Binary search tree",
                  "Priority queue",
                  "Array with linear scan",
                ].map((o, i) => (
                  <Button
                    key={o}
                    active={answer === i}
                    onClick={() => setAnswer(i)}
                  >
                    <kbd>{i + 1}</kbd>
                    <span>{o}</span>
                    {revealed && <b>{[14, 3, 1, 1][i]} votes</b>}
                  </Button>
                ))}
              </div>
              {revealed ? (
                <div className="result-note">
                  <Icon name="check" />
                  <div>
                    <strong>
                      Correct answer: Hash map + doubly linked list
                    </strong>
                    <span>
                      The map provides O(1) lookup while the list provides O(1)
                      reordering.
                    </span>
                  </div>
                </div>
              ) : (
                <Button
                  variant="primary"
                  className="submit-answer"
                  onClick={() => setRevealed(true)}
                >
                  Submit answer
                </Button>
              )}
            </div>
          )}
        </section>
        <aside className="panel leaderboard">
          <div className="panel-heading">
            <div>
              <strong>Leaderboard</strong>
              <span>After 2 questions</span>
            </div>
          </div>
          {[
            "Sana Patel",
            "Aarav Kumar",
            "Ishita Shah",
            "Rahul Mehta",
            "Meera Nair",
          ].map((n, i) => (
            <div className="rank-row" key={n}>
              <span>{i + 1}</span>
              <strong>{n}</strong>
              <code>{[1980, 1920, 1870, 1820, 1760][i]} pts</code>
            </div>
          ))}
          <div className="participation">
            <span>PARTICIPATION</span>
            <strong>84%</strong>
            <div>
              <i />
            </div>
            <small>16 of 19 participants answered</small>
          </div>
        </aside>
      </div>
    </div>
  )
}

function FeaturesView() {
  const doubts = [
    "Why does eviction happen at the tail?",
    "How do we update an existing key?",
    "Can OrderedDict be used in interviews?",
  ]
  return (
    <div className="page">
      <PageHeader
        title="Studyroom core features"
        description="A learning workspace designed around outcomes, not meeting time."
        action={
          <Button variant="primary" icon="plus">
            Start focused session
          </Button>
        }
      />
      <div className="feature-grid">
        <section className="feature-block goal-feature">
          <div className="feature-icon">
            <Icon name="target" />
          </div>
          <span className="section-kicker">SESSION GOAL</span>
          <div className="title-md">Solve 3 LRU problems</div>
          <p>Keep everyone aligned on one concrete outcome.</p>
          <div className="step-list">
            <span className="done">
              <Icon name="check" /> Implement get()
            </span>
            <span className="done">
              <Icon name="check" /> Implement put()
            </span>
            <span>
              <i /> Explain eviction strategy
            </span>
          </div>
          <div className="goal-bar">
            <span style={{ width: "67%" }} />
            <b>2 / 3</b>
          </div>
        </section>
        <section className="feature-block timer-feature">
          <div className="feature-icon">
            <Icon name="clock" />
          </div>
          <span className="section-kicker">SHARED FOCUS TIMER</span>
          <strong className="feature-time">24:18</strong>
          <p>Every participant sees the same synced countdown.</p>
          <div className="focus-phases">
            <span className="active">Focus 25m</span>
            <span>Break 5m</span>
            <span>Focus 25m</span>
          </div>
          <Button icon="pause" variant="primary">
            Pause for everyone
          </Button>
        </section>
        <section className="feature-block streak-feature">
          <div className="feature-icon">
            <Icon name="flame" />
          </div>
          <span className="section-kicker">ACCOUNTABILITY</span>
          <strong className="feature-time">12 days</strong>
          <p>Current study streak · personal best 21 days</p>
          <div className="streak-days">
            {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
              <span className={i < 5 ? "done" : ""} key={i}>
                {i < 5 && <Icon name="check" size={12} />}
                <small>{d}</small>
              </span>
            ))}
          </div>
          <small>14h 20m focused this week</small>
        </section>
        <section className="feature-block doubt-feature">
          <div className="feature-icon">
            <Icon name="help" />
          </div>
          <span className="section-kicker">PRIORITY DOUBT QUEUE</span>
          <div className="title-md">Questions that need attention</div>
          {doubts.map((d, i) => (
            <div className="mini-doubt" key={d}>
              <code>▲ {12 - i * 3}</code>
              <span>{d}</span>
              <b>{i === 2 ? "ANSWERED" : "OPEN"}</b>
            </div>
          ))}
          <Button>Open doubt queue</Button>
        </section>
        <section className="feature-block recap-feature">
          <div className="feature-icon">
            <Icon name="book" />
          </div>
          <span className="section-kicker">AUTOMATIC RECAP</span>
          <div className="title-md">Keep what the group learned</div>
          <div className="recap-mini-stats">
            <span>
              <strong>48m</strong>Focused
            </span>
            <span>
              <strong>3</strong>Solved
            </span>
            <span>
              <strong>4</strong>Answered
            </span>
          </div>
          <div className="recap-thumb">
            <Icon name="board" />
            <span>Board · 2 pages saved</span>
          </div>
          <Button icon="whatsapp">Share recap</Button>
        </section>
      </div>
    </div>
  )
}

function SettingsView() {
  const [section, setSection] = useState("Profile")
  const sections = [
    "Profile",
    "Appearance",
    "Notifications",
    "Integrations",
    "Study habits",
  ]
  return (
    <div className="page settings-page">
      <PageHeader
        title="Settings"
        description="Manage your profile, study defaults, and integrations."
      />
      <div className="settings-layout">
        <aside className="settings-nav">
          {sections.map((s) => (
            <Button
              key={s}
              active={section === s}
              onClick={() => setSection(s)}
            >
              {s}
              <Icon name="chevron" />
            </Button>
          ))}
        </aside>
        <div className="settings-content">
          <section className="settings-section">
            <div className="section-title">
              <div>
                <strong>{section}</strong>
                <span>
                  {section === "Integrations"
                    ? "Connect optional tools using credentials you control."
                    : "Your preferences are synced across study rooms."}
                </span>
              </div>
            </div>
            {section === "Integrations" ? (
              <>
                <div className="integration-card">
                  <div className="integration-head">
                    <span className="integration-icon">
                      <Icon name="key" />
                    </span>
                    <div>
                      <strong>Use your own AI key</strong>
                      <span>
                        Optional tools for captions and explaining selected
                        notes
                      </span>
                    </div>
                    <span className="status-muted">NOT CONNECTED</span>
                  </div>
                  <div className="settings-fields">
                    <Field label="PROVIDER" value="OpenAI" />
                    <Field
                      label="API KEY"
                      value="••••••••••••••••"
                      type="password"
                    />
                    <Field label="MODEL" value="gpt-4.1-mini" />
                  </div>
                  <div className="integration-actions">
                    <Button disabled>Test connection</Button>
                    <Button variant="primary">Save key</Button>
                  </div>
                  <p className="privacy-note">
                    <Icon name="signal" /> Stored in this browser only. Never
                    sent to our servers.
                  </p>
                </div>
                <SettingRow
                  title="Live captions"
                  description="Generate live captions during study rooms"
                  disabled
                />
                <SettingRow
                  title="Explain selection"
                  description="Explain selected board text or code"
                  disabled
                />
              </>
            ) : section === "Study habits" ? (
              <>
                <SettingRow
                  title="Default focus timer"
                  description="25 minutes focus · 5 minutes break"
                  action={<Button>Change</Button>}
                />
                <SettingRow
                  title="Daily study reminder"
                  description="Every day at 7:00 PM"
                  checked
                />
                <SettingRow
                  title="Solo study reminders"
                  description="Remind me when I miss a planned focus block"
                  checked
                />
                <SettingRow
                  title="Weekly study target"
                  description="18 focused hours per week"
                  action={<Button>18 hours</Button>}
                />
              </>
            ) : (
              <>
                <div className="profile-row">
                  <div className="profile-avatar">AK</div>
                  <div>
                    <strong>Aarav Kumar</strong>
                    <span>aarav.kumar@example.com</span>
                  </div>
                  <Button>Change photo</Button>
                </div>
                <div className="settings-fields two">
                  <Field label="DISPLAY NAME" value="Aarav Kumar" />
                  <Field label="TIME ZONE" value="Asia/Kolkata (GMT+5:30)" />
                </div>
                <SettingRow
                  title="Live room notifications"
                  description="Doubts, polls, hand raises, and focus breaks"
                  checked
                />
                <SettingRow
                  title="Low-data suggestions"
                  description="Suggest audio + board mode on slow networks"
                  checked
                />
              </>
            )}
          </section>
        </div>
      </div>
    </div>
  )
}

function SettingRow({
  title,
  description,
  checked,
  disabled,
  action,
}: {
  title: string
  description: string
  checked?: boolean
  disabled?: boolean
  action?: ReactNode
}) {
  return (
    <div className={`setting-row ${disabled ? "disabled" : ""}`}>
      <div>
        <strong>{title}</strong>
        <span>{description}</span>
      </div>
      {action || <Toggle checked={checked} disabled={disabled} />}
    </div>
  )
}

function RecapView({ onNavigate }: { onNavigate: (view: ViewName) => void }) {
  return (
    <div className="page recap-page">
      <PageHeader
        title="Session complete"
        description="LRU Cache · Interview Prep · Today, 10:30–11:18 AM"
        action={
          <div className="header-actions">
            <Button icon="download">Download PDF</Button>
            <Button icon="whatsapp" variant="primary">
              Share to WhatsApp
            </Button>
          </div>
        }
      />
      <div className="recap-layout">
        <div>
          <section className="recap-hero">
            <div>
              <span className="section-kicker">SESSION OUTCOME</span>
              <div className="title-lg">Goal achieved</div>
              <p>Solved 3 LRU Cache problems together</p>
            </div>
            <div className="recap-ring">
              <strong>48</strong>
              <span>MIN FOCUS</span>
            </div>
          </section>
          <section className="stats-strip recap-stats">
            <StatCell
              icon="users"
              value="19"
              label="Attendees"
              detail="14 active participants"
            />
            <StatCell
              icon="code"
              value="3"
              label="Problems solved"
              detail="2 medium · 1 hard"
            />
            <StatCell
              icon="help"
              value="4 / 5"
              label="Doubts answered"
              detail="1 saved for next time"
            />
            <StatCell
              icon="stats"
              value="82%"
              label="Quiz accuracy"
              detail="5 questions"
            />
          </section>
          <section className="panel learning-summary">
            <div className="panel-heading">
              <div>
                <strong>Key learnings</strong>
                <span>Captured from the board and answered doubts</span>
              </div>
              <Button>Generate flashcards</Button>
            </div>
            {[
              "Hash map provides O(1) access to cache nodes",
              "Doubly linked list maintains recency order in O(1)",
              "Move accessed nodes to the head; evict from the tail",
            ].map((x, i) => (
              <div key={x}>
                <span>{i + 1}</span>
                <strong>{x}</strong>
              </div>
            ))}
          </section>
          <section className="panel board-captures">
            <div className="panel-heading">
              <div>
                <strong>Board captures</strong>
                <span>2 pages saved to room history</span>
              </div>
              <Button>Open board</Button>
            </div>
            <div>
              <div className="board-thumb">
                <Board />
              </div>
              <div className="board-thumb second">
                <Board />
              </div>
            </div>
          </section>
        </div>
        <aside>
          <section className="panel recap-share">
            <span className="section-kicker">SHAREABLE RECAP</span>
            <div className="share-card">
              <div className="wordmark">
                <span className="brand-mark">N</span>
                <strong>Notionroom</strong>
              </div>
              <span>LRU CACHE · DSA</span>
              <strong>48 min of focused learning</strong>
              <div>
                <b>3</b> problems <b>4</b> doubts <b>19</b> learners
              </div>
              <small>12 day study streak · Group rank #3</small>
            </div>
            <Button icon="copy">Copy recap link</Button>
          </section>
          <section className="panel top-doubts">
            <div className="panel-heading">
              <div>
                <strong>Top doubts answered</strong>
              </div>
            </div>
            {[
              "Why move accessed nodes to the head?",
              "Can OrderedDict be used in interviews?",
              "How is an existing key updated?",
            ].map((x, i) => (
              <div key={x}>
                <code>0{i + 1}</code>
                <span>{x}</span>
              </div>
            ))}
          </section>
          <Button
            variant="primary"
            icon="check"
            className="save-history"
            onClick={() => onNavigate("home")}
          >
            Save to study history
          </Button>
        </aside>
      </div>
    </div>
  )
}

export default function App() {
  const [theme, setTheme] = useState<"dark" | "light">("dark")
  const [view, setView] = useState<ViewName>("home")
  if (view === "join")
    return (
      <div className="app" data-theme={theme}>
        <JoinView
          theme={theme}
          setTheme={setTheme}
          onJoin={() => setView("room")}
        />
      </div>
    )
  if (view === "room")
    return <RoomView theme={theme} setTheme={setTheme} onNavigate={setView} />
  const content =
    view === "home" ? (
      <HomeView onNavigate={setView} />
    ) : view === "schedule" ? (
      <ScheduleView onNavigate={setView} />
    ) : view === "stats" ? (
      <StatsView />
    ) : view === "quiz" ? (
      <QuizView />
    ) : view === "features" ? (
      <FeaturesView />
    ) : view === "settings" ? (
      <SettingsView />
    ) : (
      <RecapView onNavigate={setView} />
    )
  return (
    <div className="app" data-theme={theme}>
      <AppShell
        view={view}
        onNavigate={setView}
        theme={theme}
        setTheme={setTheme}
      >
        {content}
      </AppShell>
    </div>
  )
}

function Button({
  children,
  icon,
  variant = "ghost",
  active,
  onClick,
  title,
  className = "",
  disabled,
}: {
  children?: ReactNode
  icon?: IconName
  variant?: "ghost" | "primary" | "danger"
  active?: boolean
  onClick?: () => void
  title?: string
  className?: string
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={`btn btn-${variant} ${active ? "active" : ""} ${className}`}
    >
      {icon && <Icon name={icon} />}
      {children}
    </button>
  )
}

const participants = [
  {
    name: "Aarav",
    initials: "AK",
    role: "Host · presenting",
    className: "p-green",
  },
  { name: "Ishita", initials: "IS", role: "Solving", className: "p-blue" },
  {
    name: "Rahul",
    initials: "RM",
    role: "Hand raised · #1",
    className: "p-amber",
    hand: true,
  },
  { name: "Meera", initials: "MN", role: "Focus mode", className: "p-rose" },
]

function VideoTile({
  person,
  active = false,
}: {
  person: typeof participants[number]
  active?: boolean
}) {
  return (
    <div className={`video-tile ${active ? "speaking" : ""}`}>
      <div className={`avatar-large ${person.className}`}>
        {person.initials}
      </div>
      <div className="video-meta">
        <div>
          <strong>{person.name}</strong>
          <span>{person.role}</span>
        </div>
        <Icon name={person.name === "Meera" ? "mic" : "video"} />
      </div>
      {person.hand && (
        <div className="hand-badge">
          <Icon name="hand" size={12} /> 1
        </div>
      )}
    </div>
  )
}

function Board() {
  const [tool, setTool] = useState<IconName>("pen")
  const tools: IconName[] = [
    "pen",
    "laser",
    "eraser",
    "shape",
    "arrow",
    "type",
    "image",
  ]
  return (
    <div className="board-wrap">
      <div className="board-top">
        <div className="page-tabs">
          <Button active>Page 1</Button>
          <Button>Page 2</Button>
          <Button>+</Button>
        </div>
        <div className="board-actions">
          <Button icon="undo" title="Undo" />
          <Button icon="redo" title="Redo" />
          <span className="zoom-label">84%</span>
          <Button icon="zoom" title="Zoom" />
          <Button icon="download">Export</Button>
          <span className="permission">
            <span /> Everyone can draw
          </span>
        </div>
      </div>
      <div className="canvas">
        <div className="tool-rail">
          {tools.map((item) => (
            <Button
              key={item}
              icon={item}
              active={tool === item}
              onClick={() => setTool(item)}
              title={item}
            />
          ))}
        </div>
        <div className="goal-note">
          <span>SESSION GOAL</span>
          <strong>Solve 3 problems together</strong>
          <small>2 of 3 completed</small>
          <div>
            <i />
          </div>
        </div>
        <svg
          className="diagram"
          viewBox="0 0 820 440"
          role="img"
          aria-label="System design diagram for a scalable URL shortener"
        >
          <defs>
            <marker
              id="arrowhead"
              markerWidth="8"
              markerHeight="8"
              refX="7"
              refY="4"
              orient="auto"
            >
              <path d="M0 0 L8 4 L0 8" fill="none" stroke="currentColor" />
            </marker>
          </defs>
          <g className="diagram-lines" markerEnd="url(#arrowhead)">
            <path d="M150 222H260" />
            <path d="M400 222H470" />
            <path d="M610 190 700 125" />
            <path d="M610 222h90" />
            <path d="M610 255l90 65" />
          </g>
          <g className="diagram-boxes">
            <rect x="40" y="180" width="110" height="84" rx="6" />
            <text x="95" y="211">
              CLIENT
            </text>
            <text x="95" y="235">
              Web / Mobile
            </text>
            <rect x="260" y="176" width="140" height="92" rx="6" />
            <text x="330" y="209">
              LOAD BALANCER
            </text>
            <text x="330" y="234">
              Round robin
            </text>
            <rect x="470" y="110" width="140" height="64" rx="6" />
            <text x="540" y="138">
              API SERVER 01
            </text>
            <text x="540" y="158">
              Node.js
            </text>
            <rect x="470" y="190" width="140" height="64" rx="6" />
            <text x="540" y="218">
              API SERVER 02
            </text>
            <text x="540" y="238">
              Node.js
            </text>
            <rect x="470" y="270" width="140" height="64" rx="6" />
            <text x="540" y="298">
              API SERVER 03
            </text>
            <text x="540" y="318">
              Node.js
            </text>
            <path d="M700 92h94v66h-94z" />
            <path d="M700 105c0 8 94 8 94 0M700 142c0 8 94 8 94 0" />
            <text x="747" y="129">
              REDIS
            </text>
            <path d="M700 190h94v66h-94z" />
            <path d="M700 203c0 8 94 8 94 0M700 240c0 8 94 8 94 0" />
            <text x="747" y="227">
              POSTGRES
            </text>
            <path d="M700 286h94v66h-94z" />
            <path d="M700 299c0 8 94 8 94 0M700 336c0 8 94 8 94 0" />
            <text x="747" y="323">
              KAFKA
            </text>
          </g>
          <g className="red-marks">
            <path d="M685 178c30-19 100-17 120 10" />
            <path d="m797 176 9 12-16 2" />
          </g>
        </svg>
        <div className="cursor cursor-a">Ishita</div>
        <div className="cursor cursor-b">Sana</div>
        <div className="laser-dot">
          <span>Rahul</span>
        </div>
        <div className="mobile-lowdata">
          <Icon name="signal" /> Audio + board only <Toggle />
        </div>
        <div className="pan-hint">Two-finger pan · Pinch to zoom</div>
      </div>
    </div>
  )
}

function SidePanel() {
  const [tab, setTab] = useState("Doubts")
  const tabs = ["Chat", "Doubts", "People", "Ranks"]
  return (
    <aside className="side-panel">
      <div className="filmstrip">
        {participants.map((person, index) => (
          <VideoTile key={person.name} person={person} active={index === 0} />
        ))}
        <div className="overflow-count">+15</div>
      </div>
      <div className="side-tabs">
        {tabs.map((item) => (
          <Button key={item} active={tab === item} onClick={() => setTab(item)}>
            {item}
            {item === "Doubts" && <b>4</b>}
          </Button>
        ))}
      </div>
      <div className="panel-content">
        {tab === "Doubts" ? (
          <Doubts />
        ) : tab === "People" ? (
          <People />
        ) : tab === "Ranks" ? (
          <Ranks />
        ) : (
          <Chat />
        )}
      </div>
    </aside>
  )
}

function Doubts() {
  return (
    <div className="doubts">
      <div className="filter-row">
        <span>Sorted by votes</span>
        <Button>
          All types <Icon name="chevron" size={12} />
        </Button>
      </div>
      <div className="doubt pinned">
        <div className="vote">
          <Button>▲</Button>
          <strong>12</strong>
        </div>
        <div>
          <div className="doubt-head">
            <span className="chip">Conceptual</span>
            <span>PINNED</span>
          </div>
          <p>
            Why do we move the recently accessed node to the head instead of the
            tail?
          </p>
          <small>Ishita · 10:42</small>
          <Button variant="primary">Show on stage</Button>
        </div>
      </div>
      <div className="doubt">
        <div className="vote">
          <Button>▲</Button>
          <strong>8</strong>
        </div>
        <div>
          <div className="doubt-head">
            <span className="chip">Debugging</span>
            <span className="open">OPEN</span>
          </div>
          <p>My hashmap updates, but the linked list keeps the stale value.</p>
          <small>Anonymous · 10:46</small>
        </div>
      </div>
      <div className="doubt answered">
        <div className="vote">
          <Button>▲</Button>
          <strong>5</strong>
        </div>
        <div>
          <div className="doubt-head">
            <span className="chip">Interview</span>
            <span>
              <Icon name="check" size={11} /> ANSWERED
            </span>
          </div>
          <p>Would an interviewer accept OrderedDict here?</p>
          <small>Meera · 10:51</small>
        </div>
      </div>
      <div className="composer">
        <div>Ask a doubt...</div>
        <Button variant="primary">Ask</Button>
      </div>
    </div>
  )
}

function People() {
  return (
    <div className="people-list">
      <div className="section-label">IN THIS ROOM · 19</div>
      {participants.map((p, i) => (
        <div className="person-row" key={p.name}>
          <div className={`avatar ${p.className}`}>{p.initials}</div>
          <div>
            <strong>
              {p.name} {i === 0 && "(you)"}
            </strong>
            <span>{p.role}</span>
          </div>
          <span className="role-tag">
            {i === 0 ? "HOST" : i === 2 ? "MENTOR" : "STUDENT"}
          </span>
        </div>
      ))}
    </div>
  )
}

function Ranks() {
  return (
    <div className="ranks">
      <div className="section-label">TODAY'S QUIZ</div>
      {[
        "Aarav Kumar",
        "Sana Patel",
        "Ishita Shah",
        "Rahul Mehta",
        "Meera Nair",
      ].map((n, i) => (
        <div className="rank-row" key={n}>
          <span>{i + 1}</span>
          <strong>{n}</strong>
          <code>{[980, 920, 870, 820, 760][i]} pts</code>
        </div>
      ))}
    </div>
  )
}

function Chat() {
  return (
    <div className="chat">
      <div className="activity">10:38 · Focus session started for everyone</div>
      <p>
        <strong>Sana</strong>
        <span>10:41</span> I added the eviction flow to page 2.
      </p>
      <p>
        <strong>Meera</strong>
        <span>10:43</span> The O(1) lookup makes sense now.
      </p>
      <div className="activity">10:49 · Aarav solved 2 problems</div>
    </div>
  )
}

function GridView() {
  return (
    <div className="grid-view">
      {[
        ...participants,
        {
          name: "Sana",
          initials: "SP",
          role: "Reviewing notes",
          className: "p-cyan",
        },
      ].map((p, i) => (
        <VideoTile key={p.name} person={p} active={i === 1} />
      ))}
      <div className="board-preview">
        <Board />
        <span>Shared board · Click to expand</span>
      </div>
    </div>
  )
}

function RoomView({
  theme,
  setTheme,
  onNavigate,
}: {
  theme: "dark" | "light"
  setTheme: (theme: "dark" | "light") => void
  onNavigate: (view: ViewName) => void
}) {
  const [layout, setLayout] = useState<"stage" | "grid">("stage")
  const [seconds, setSeconds] = useState(24 * 60 + 18)
  const [running, setRunning] = useState(true)
  const [stageTab, setStageTab] = useState("Board")
  const [sheetOpen, setSheetOpen] = useState(false)

  useEffect(() => {
    if (!running) return
    const interval = window.setInterval(
      () => setSeconds((value) => Math.max(0, value - 1)),
      1000,
    )
    return () => window.clearInterval(interval)
  }, [running])
  const time = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`

  return (
    <div className="app" data-theme={theme}>
      <header className="topbar">
        <div className="room-identity">
          <Button
            className="brand-button"
            onClick={() => onNavigate("home")}
            title="Back to home"
          >
            <span className="brand-mark">N</span>
          </Button>
          <div>
            <strong>LRU Cache · Interview Prep</strong>
            <span>
              ROOM <code>DSA-482</code>
            </span>
          </div>
        </div>
        <div className="goal-chip">
          <span>GOAL</span> Solve 3 LRU questions <b>2/3</b>
        </div>
        <div className={`timer ${running ? "" : "paused"}`}>
          <span>FOCUS</span>
          <strong>{time}</strong>
          <Button
            icon={running ? "pause" : "play"}
            onClick={() => setRunning(!running)}
            title={running ? "Pause timer" : "Start timer"}
          />
        </div>
        <div className="top-actions">
          <Button icon="signal" className="network">
            Good
          </Button>
          <Button icon="users">19</Button>
          <Button icon="invite" variant="primary">
            Invite
          </Button>
          <Button
            icon={theme === "dark" ? "sun" : "moon"}
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            title="Change theme"
          />
          <Button
            icon="leave"
            variant="danger"
            onClick={() => onNavigate("recap")}
          >
            Leave
          </Button>
        </div>
      </header>

      <main className={`workspace layout-${layout}`}>
        <section className="stage">
          {layout === "stage" ? (
            <>
              <div className="stage-tabs">
                {["Board", "Screen", "Problem"].map((item) => (
                  <Button
                    key={item}
                    icon={
                      item === "Board"
                        ? "board"
                        : item === "Screen"
                          ? "screen"
                          : "code"
                    }
                    active={stageTab === item}
                    onClick={() => setStageTab(item)}
                  >
                    {item}
                  </Button>
                ))}
                <div className="stage-status">
                  <span className="live-dot" /> Aarav is presenting{" "}
                  <Button icon="chevron" />
                </div>
              </div>
              {stageTab === "Board" ? (
                <Board />
              ) : (
                <div className="placeholder-view">
                  <Icon
                    name={stageTab === "Problem" ? "code" : "screen"}
                    size={32}
                  />
                  <strong>
                    {stageTab === "Problem"
                      ? "LRU Cache — Medium"
                      : "Aarav's screen"}
                  </strong>
                  <span>
                    {stageTab === "Problem"
                      ? "Design a data structure that follows the constraints of a Least Recently Used cache."
                      : "Waiting for shared content"}
                  </span>
                  <Button variant="primary">
                    {stageTab === "Problem"
                      ? "Open problem workspace"
                      : "Share screen"}
                  </Button>
                </div>
              )}
            </>
          ) : (
            <GridView />
          )}
        </section>
        <SidePanel />
      </main>

      <footer className="controlbar">
        <div className="session-state">
          <span className="live-dot" /> FOCUS SESSION 2 <b>38 min studied</b>
        </div>
        <div className="controls">
          <Button icon="mic" active>
            Mic <Icon name="chevron" size={11} />
          </Button>
          <Button icon="video">
            Camera <Icon name="chevron" size={11} />
          </Button>
          <Button icon="screen">Share</Button>
          <Button icon="hand">Raise hand</Button>
          <Button
            icon="message"
            className="mobile-only"
            onClick={() => setSheetOpen(!sheetOpen)}
          >
            Panel
          </Button>
          <Button
            icon="grid"
            active={layout === "grid"}
            onClick={() => setLayout(layout === "stage" ? "grid" : "stage")}
          >
            {layout === "stage" ? "Grid" : "Stage"}
          </Button>
          <Button icon="more" title="More" />
        </div>
        <div className="mode">
          <span>STUDY MODE</span>
          <strong>Focus</strong>
          <Icon name="chevron" size={12} />
        </div>
      </footer>

      <div className={`mobile-sheet ${sheetOpen ? "open" : ""}`}>
        <div className="sheet-handle" onClick={() => setSheetOpen(false)} />
        <SidePanel />
      </div>
      <div className="toast">
        <Icon name="check" />
        <div>
          <strong>Board saved</strong>
          <span>It will be added to your session recap.</span>
        </div>
      </div>
    </div>
  )
}
